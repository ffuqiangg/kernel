/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2011 Kuninori Morimoto
 */
#ifndef SH_HSPI_H
#define SH_HSPI_H

struct sh_hspi_info {
};

#endif
