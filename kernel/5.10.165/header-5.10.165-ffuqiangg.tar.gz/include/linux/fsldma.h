/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 */

#ifndef FSL_DMA_H
#define FSL_DMA_H
/* fsl dma API for enxternal start */
int fsl_dma_external_start(struct dma_chan *dchan, int enable);

#endif
