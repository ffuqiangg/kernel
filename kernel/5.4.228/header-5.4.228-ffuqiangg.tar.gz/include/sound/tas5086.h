/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _SND_SOC_CODEC_TAS5086_H_
#define _SND_SOC_CODEC_TAS5086_H_

#define TAS5086_CLK_IDX_MCLK	0
#define TAS5086_CLK_IDX_SCLK	1

#endif /* _SND_SOC_CODEC_TAS5086_H_ */
